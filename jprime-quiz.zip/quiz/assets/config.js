const STORAGE_KEY = "persistedCandidates";
const TIME_IN_SECONDS = 120;